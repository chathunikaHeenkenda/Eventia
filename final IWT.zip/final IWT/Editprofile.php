<?php
session_start();
	require 'config.php';
	
	
if(count($_POST)>0){
	mysqli_query($conn,"UPDATE user_1 SET FullName='".$_POST['FullName']."',Email='".$_POST['Email']."',UserName='".$_POST['UserName']."',Phone='".$_POST['Phone']."'WHERE Email='".$_POST['Email']."'");
	$message = "Record Modified successfullly";
	header('location:home.php');
	
}

$result = mysqli_query($conn,"SELECT * FROM user_1 WHERE user_id='".$_GET['user_id']."'");
$row=mysqli_fetch_array($result);
?>


<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel = "stylesheet" href="style/register.css">
	<link rel = "stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	
	
	<!--add a title-->
	<title>EVENTIA</title>

	<!--add a logo-->
	<div class="topic"style="background-color:black;
	height:100px;
	position:absolute;
	top:0;
	width:1550px;">
	<img src = "images/images/logo2.jpg" width="100px" height="100px">
	
	<!--add a header-->
	<h1 style="margin : 0;
	padding	: 0 0 20px;
	font-size : 60px;
	text-align : center;
	color:green;
	top:6%;
	position:absolute;
	left:45%;
	">EVENTiA</h1>
	</div>
	
	
	<script>
	function myFun(){
		var b= document.getElementById("psw").value;
		var c= document.getElementById("c_psw").value;
		
		
		if(b!=c){
			document.getElementById("messages").innerHTML="**password are not same"
			return false;

		}
		
	}
	</script>
	
</head>	
<body ">	
	
		
		<form method="post" action="" name="myForm" onsubmit="return myFun();" style="width:500px;">
		<div><?php if(isset($message)){echo $message;}?>
</div>
		
		<center><div class="register form"style="background-color:black;
	width : 700px;
	height : 600px;
	background:#00396c;
	top : 20%;
	left : 20%;
	position : absolute;
	Box-sizing : boarder-box;
	padding:50px 20px;
	margin-bottom:10%;
	opacity:0.8;
	color:white;">
	
			<h2>Update profile</h2>
			<div class="form-group"style="width:1000px;"></div>
			
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="id" name="user_id"placeholder="user_id" size="60"value="<?php echo $_SESSION['user_id'];?> "disabled><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="Fn" name="FullName"placeholder="Full name" size="60"value="<?php echo $_SESSION['FullName'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="Email"placeholder="Email"size="60" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}" value="<?php echo $_SESSION['Email'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="Us" name="UserName"placeholder="User Name" size="60"value="<?php echo $_SESSION['UserName'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="PN"value="" placeholder="Phone number" size="60" name="Phone"value="<?php echo $_SESSION['Phone'];?>" pattern="[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]" required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"id="psw" name="password"placeholder="Password"size="60px"value="<?php echo $_SESSION['password'];?>" required>
			<span id="messages"></span><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"id="c_psw" name="psw"size="60px" name="confirm"placeholder="confirm password"required><br><br>
			<span id="messages"></span><br><br>	
			<input type="submit" value="submit"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:blue;
    color: #fff;
    font-size: 20px;
    border-radius: 20px;
	width:100px"></a><br>
			</center>
		</form>
		
		</div>
		
		<div>
		<a href="home.php"><input type="submit" value="Home"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:green;
    color: #fff;
    font-size: 20px;
	width:150px;
	position:absolute;
	left:79%;
	top:20%;"></a><br>
	
	<a href="reserv.php"><input type="submit" value="Revervation"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:green;
    color: #fff;
    font-size: 20px;
	width:150px;
	position:absolute;
	left:79%;
	top:40%;"></a><br>
	
	<a href="contact.php"><input type="submit" value="Contact us"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:green;
    color: #fff;
    font-size: 20px;
	width:150px;
	position:absolute;
	left:79%;
	top:60%;"></a><br>
	
	<a href="aboutus.php"><input type="submit" value="About us"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:green;
    color: #fff;
    font-size: 20px;
	width:150px;
	position:absolute;
	left:79%;
	top:80%;"></a><br>
		</div>
		
	
</body>
<footer class="footer-distributed"style="
	position:absolute;
	background-color:black;
	color:white;
	bottom:0;
	width:300%;
	height:80%;
	left:-120%;
	top:800px;
	text-align:center;
	
">
			<br><br><br><br><br><br>
				<p>Eventia ! &copy; 2019</p>
			
			<div>
				<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
			</div>

			<div>
				<p>+9481123256</p>
			</div>

			<div>
				<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
			</div>

			<p> 
				<span>About Eventia</span>
				Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
			</p>

</footer>


</html>
	
	