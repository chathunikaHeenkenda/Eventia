<?php
		
		session_start();
		require('config.php');

		
?>

<!DOCTYPE html>
<html>


<head>
	<link rel  = "stylesheet" href="style/aboutus.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!--add a title-->
	<title>EVENTIA</title>
	
	
</head>
<body>
	<!--add a logo-->
	<img src = "images/images/logo2.jpg" width="100px" height="100px">
	<div style="left:94%;position:absolute;top:150px;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
	
	<!--add a header-->
	<h1>EVENTiA</h1>
	
	<!--add a horizantal line-->
	<hr>
	<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
	
	
	</hr>
	<!-- About the event planning system-->
    <div class = "left">	
	<h2> About Us</h2>
	<span class="border"></span>
	<div class="ps">
		<a href="#p1"><img src="images/images/p1.jpg" alt=""></a>
		<a href="#"><img src="images/images/p2.jpg" alt=""></a>
		<a href="#"><img src="images/images/p2.jpg" alt=""></a>
		<a href="#"><img src="images/images/p4.jpg" alt=""></a>
		<a href="#"><img src="images/images/p5.jpg" alt=""></a>
	</div>	
	
	<div class="section"id="p1">
	<span class="name"></span>
	<span class="border"></span>
	<div class="ds-box">
	<p>
	  We have been oraganizing evets since the very 2010.  Our Philosophy is simple: If you engage with our services for your event, we will handle everything, leaving you free to cherish and live the moment, 
         making you feel like the guest of honour at your own event.
		 We plan differernt types of events as below;
	</p>
	</div>
	</div>
   
</body>
	<footer class="footer-distributed">
			<br><br><br><br><br><br>
			<div>
				<p>Eventia ! &copy; 2019</p>
			</div>
			<div>
				<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
			</div>

			<div>
				<p>+9481123256</p>
			</div>

			<div>
				<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
			</div>

			<p> 
				<span>About Eventia</span>
				Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
			</p>

	











</html>