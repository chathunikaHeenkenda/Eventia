



<?php
require 'config.php';

$Deco_name = $_POST['dname'];

$price = $_POST['dprice'];

$sql = "INSERT into decoration(ID,Decoration,Price)VALUES('','$Deco_name','$price')";

if(mysqli_query($conn , $sql))
{
	echo "<script> alert ('successfully inserted')</script>";
	header("location:admin.php");
}	
else
{
	
	echo "<script> alert ('error')</script>";
	
}


