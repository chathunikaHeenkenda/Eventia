
<?php
require 'config.php';

$Hotel_name = $_POST['hname'];

$price = $_POST['hprice'];

$sql = "INSERT into hotel(ID,HotelName,Price)VALUES('','$Hotel_name','$price')";

if(mysqli_query($conn , $sql))
{
	echo "<script> alert ('successfully inserted')</script>";
	header("location:admin.php");
}	
else
{
	
	echo "<script> alert ('error')</script>";
	
}
?>
	/*$sql2="SELECT *FROM hotel";
	$result = $con->query($sql2);
	
	
	if($result->num_rows>0)
	{
		while($row = $result->fetch_assoc())
		{
			echo $row["HotelName"]."-".$row["Price"]."<br/>";
		}
	}
	else {
		
		echo "no results";
	}
	//close the connection
	
	$conn->close();*/