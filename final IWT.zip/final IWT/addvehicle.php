<?php
require 'config.php';

$Vehicle_name = $_POST['vname'];

$price = $_POST['vprice'];

$sql = "INSERT into car(ID,Car,Price)VALUES('','$Vehicle_name','$price')";

if(mysqli_query($conn , $sql))
{
	echo "<script> alert ('successfully inserted')</script>";
	header("location:admin.php");
}	
else
{
	
	echo "<script> alert ('error')</script>";
	
}
	