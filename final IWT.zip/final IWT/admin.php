<html>

	<head>
		<link rel  = "stylesheet" href="admin.css">
	
		<title>Admin panel</title>
	</head>
	<body>
		<div id = "header"style="height:150px;">
		
		<?php
		date("y-m-d");
		?>
		
		<img src = "images/images/logo2.jpg" width="100px" height="100px">
		
		<center><img src = "avatar.png" alt = "admin logo" id = "adminlogo" style="top:5%;position:absolute;"></center>
		
		</div>
		<div id = "sidebar">
		<ul>
		<li><a href = "addhotels.html" style = "color: white; text-decoration: none";>Add Hotels</a></li>
		<li><a href = "adddeco.html" style = "color: white; text-decoration: none";>Add Deoration</a></li>
		<li><a href = "addvehicle.html" style = "color: white; text-decoration: none";>Add Vehicle</a></li>
		<li><a href = "viewhotels.php" style = "color: white; text-decoration: none";>View Hotels</a></li>
		<li><a href = "viewdeco.php" style = "color: white; text-decoration: none";>View Decoration</a></li>
		<li><a href = "viewvehicle.php" style = "color: white; text-decoration: none";>View Vehicle</a></li>
		<li><a href = "logout.php" style = "color: white; text-decoration: none";>Log off</a></li>
		
		<!--<li><a href = "#" style = "color: white; text-decoration: none";>Update options</a></li>
		<a href = "#" style = "color: white; text-decoration: none";><li>statics</li></a>-->
		</ul>
		</div>
		<div id = "data"><br>
		<center>
		<h1 style="font-size:50px;">Eventia</h1>
		<br>
		<br>
		<h2 style ="font-size:40px;">Welcome to Admin panel!</h2>
		
		<center>
		<br>
		<br>
		</div>
	
		
		
	

	</body>




</html>