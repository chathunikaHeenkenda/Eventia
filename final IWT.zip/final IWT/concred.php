<?php
	require 'config.php';
	
	$creditCN = $_POST['ccn'];
	$bank = $_POST['bank'];
	$doe = $_POST['doe'];
	
		$sql = "INSERT INTO creditcard(CreditC_id, Credit_no, Bank, DOE) VALUES ('','$creditCN', '$bank', '$doe')";
		
		if(mysqli_query($conn, $sql))
		{
			echo "<script> alert('Successfully inserted!!') </script>";
		}
		else
		{
			echo "<script> alert('Error') </script>";
		}
		
		mysqli_close($conn);

?>