<?php
		
		session_start();
		require('config.php');

		
?>

<html>

	<head>
		<title>EVENTIA</title>
		<link rel="stylesheet" href="style/contact.css">
	</head>
	
	<body>
		<img src="images/logo.jpg" align="left" width="100px" height="100px">
		<div style="left:94%;position:absolute;top:150px;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
		
		<h1>eVENTiA</h1>
		
		<hr>
		
		<ul id="navi">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
		
		

		
	   
		
		
		
		
			<div class="background"></div>

			
			<div >

				<div style="margin-top:63px;margin-right:2px;margin-left:12%;">
					<img src="images/icon.jpg" width="50px" height="50px">
				</div>
					
				
				<div style="margin-top:-71px;margin-right:116px;margin-left:18%;">
					<p>Address:207,<br>
					New Road,<br>
					Kandy,<br>
					Sri Lanka.</p>
				</div>	
						
				
				<div style="margin-top:-81px;margin-right:137px;margin-left:44%;">
					<img src="images/phone.jpg" width="50px" height="50px"/>
				</div>

				<div style="margin-top:-38px;margin-right:16px;margin-left:50%">
					Phone:+9481123256
				</div>
				
				<div style="margin-top:-35px;margin-right:1px;margin-left:75%;">
					<img src="images/mail.jpg" width="50px" height="50px">
				</div>

				<div style="margin-top:-34px;margin-right:1px;margin-left:81%;">
					E-mail:Eventia@event.com
				</div>
				
			
			
		
		</div>
		
		
		
		
		
	
	
	
		

		
	
		<footer class="footer-distributed">
			<br><br><br><br><br><br>
				<p>Eventia ! &copy; 2019</p>
			
			<div>
				<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
			</div>

			<div>
				<p>+9481123256</p>
			</div>

			<div>
				<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
			</div>

			<p> 
				<span>About Eventia</span>
				Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
			</p>

		</footer>

	</body>
</html>