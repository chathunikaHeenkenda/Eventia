<?php
	session_start();
	require 'config.php';
	
	$Eno = $_POST['eno'];
	$Tot = $_POST['tot'];
	
	
		$sql = "INSERT INTO payment(BillNo, EventNO, TotAmount) VALUES ('','$Eno', '$Tot')";
		
		if(mysqli_query($conn, $sql))
		{
			echo "<script> alert('Successfully inserted!!') </script>";
		}
		else
		{
			echo "<script> alert('Error') </script>";
		}
		
		mysqli_close($conn);
	
?>

<!DOCTYPE html>
<html>
	<head>
		
		
		<link rel  = "stylesheet" href="style/homestyle.css">
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src ="js/home.js"></script>	
		
		<!--add a title-->
		<title>EVENTIA</title>
		
	
	</head>
	
	<body>
		<!--add a logo-->
		<img id="logo" src = "images/logo2.jpg">
		<div style="left:94%;position:absolute;top:180px;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
		
		<!--add a header-->
		<h1 id ="eventia">eVENTiA</h1>
		
		<!--add a navigation bar-->
	
		<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
			
			
	<h1 align = 'center'>Payment Details</h1><br><br><br><br>
	<form method ='post' action = 'AddCredit.php'style="background-color:#DDA0DD;
	border-width:25px;
	width:500px;
	text-align:center;
	left:400px;
	position:absolute;
	height:300px;
	opacity :0.5s;
	filter:Alpha(opacity=50);
	top:70%;
	"><br><br><br>
	
	<div style = "text-size: 50px;">
	
	<label>Credit card number:</label>
	<input type = 'text' name = 'ccn1' required><br><br>
	
	<label>Bank:</label>
	<input type = 'text' name = 'bank1' required><br><br>
	
	<label>Expire date: <label>
	<input type = 'date' name = 'doe1' required><br><br>
	
	<button input type = 'submit' name = 'button'>Check</button>
	
	</div>
	
	</form>			
	</body>

	<footer class="footer-distributed">
					<br><br><br>
					<p>Eventia ! &copy; 2019</p>
					
					<p>207,New road Kandy,<br><br>Sri lanka</p>

					<p>+9481123256</p>

					<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
					
					<p> 
						About Eventia:
							Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a 
							fingertip away.
					</p>

	</footer>


	

</html>