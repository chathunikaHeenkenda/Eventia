<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	<title>EVENTIA!</title>
	<link rel="stylesheet" href="style/default.css" type="text/css">
	
</head>
<body style="">

	<h3>WELCOME TO EVENTIA</h3><br>
	<p class="join">Join With Us</p>
	<p class="plan">Plan your event with us and it will be memorable moment for you</p>

	<a href="login.php"><input type="submit" value="Login"class="btn btn-primary"></a><br>
	<a href="register.php"><input type="submit" value="Sign-up"class="btn btn-primary1"></a><br>
	
	
	


</body>
<html>