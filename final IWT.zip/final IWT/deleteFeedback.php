<html>
	<head>
		<title>EVENTIA</title>
		<link rel="stylesheet" href="style/feedback.css">
	</head>
	

		<body>
		
		
			<img src="images/logo.jpg" align="left" width="100px" length="200px">
			<img id="profile" src="images/profile.png">
			
			<h1 align="center">eVENTiA</h1>
			
		
			
			<ul id="navi">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.html">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
		</ul>
			
			
			
			








<?php

		$servername = "localhost";
		$username = "root";
		$password = "";
		$databasename = "eventia";
	
		//creating the connection
	
		$conn = new mysqli($servername , $username , $password , $databasename);
		
		//checking the connection

		if($conn -> connect_error)
		{
			die("Connection Failed:".$conn->connect_error);
		}
				
		else
		{
			echo "Connected Succesfully";
		}
					

			$recordID = $_GET['id'];

			$sql = "DELETE FROM feedback WHERE id = '$recordID' ";

			if(mysqli_query ($conn , $sql))
			{
				echo "<script> alert('Records deleted successfully') </script>";
			}

			else
			{
				echo "<script> alert('Error when deleting!')</script>";
			}

?>

					

			<div align = "right">
			</div>
			
						<footer class="footer-distributed">
							<br><br><br><br><br><br>
								<p>Eventia ! &copy; 2019</p>
							
							<div>
								<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
							</div>

							<div>
								<p>+9481123256</p>
							</div>

							<div>
								<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
							</div>

							<p> 
								<span>About Eventia</span>
								Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
							</p>

						</footer>
		
		</body>
		
	</html>
