<?php
	require 'config.php';
	
	$recordID = $_GET['id'];
	
	$sql = "DELETE FROM creditcard where CreditC_id = '$recordID'";
	
	if(mysqli_query ($conn, $sql))
	{
		echo "<script>alert('Records deleted successfully!')</script>";
		header ("location:creditConfirm.php");
	}
	else
	{
		echo "<script>alert('Error')</script>";
	}
	
	mysqli_close($conn);
?>