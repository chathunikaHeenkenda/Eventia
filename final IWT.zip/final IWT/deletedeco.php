<?php
	require 'config.php';
	$recordID = $_GET['id'];
	
	$sql = "DELETE from decoration where ID = '$recordID'";
	
		if (mysqli_query($conn, $sql))
						{
							
							echo "<script>alert('Record deleted successfully!!')</script>";
							header("location:viewdeco.php");
							
							
							
						}
						else {
							
							echo"<script> alert ('error in deleting the record')</script>";
							
							
						}
							mysqli_close($conn);

	
	?>