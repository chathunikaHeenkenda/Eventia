<?php
	require 'config.php';


	$recordID=$_GET['id'];
	
	$sql="DELETE FROM reservation where EventNo='$recordID'";
	
	if(mysqli_query($conn,$sql))
	{
		echo "<script>alert('Deleted')</script>";
		header("Location:home.php");
		
	}
	else
	{
		echo "<script>alert('Error')</script>".$conn->error;
	}
	mysqli_close($conn)
	
	
	?>