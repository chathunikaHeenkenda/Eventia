<?php
	session_start();
	require 'config.php';
?>
<!DOCTYPE html>
<html>
	<head>
		
		
		<link rel  = "stylesheet" href="style/homestyle.css">
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src ="js/home.js"></script>	
		
		<!--add a title-->
		<title>EVENTIA</title>
		
	
	</head>
	
	<body>
		<!--add a logo-->
		<img id="logo" src = "images/logo2.jpg">
		<div style="left:94%;position:absolute;top:120px;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
		
		<!--add a header-->
		<h1 id ="eventia">eVENTiA</h1>
		
		<!--add a navigation bar-->
	
		<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
		
		<?php
							$recordId = $_GET['id'];
							
							$sql = "select* from creditcard where CreditC_id = $recordId ";
							
							$result = $conn -> query($sql);
							
							if($result -> num_rows > 0)
							{
								while($row = $result -> fetch_assoc())
								{
									$id = $row['CreditC_id'];
									$no = $row['Credit_no'];
									$bank = $row['Bank'];
									$doe = $row['DOE'];
								}
							}
							else
							{
								echo "0 results";
							}
						?>
	
			
			
	<h1 align = 'center'>Payment Details</h1><br><br><br><br>
			<center>
				<div>
					<h1 align = 'center'>Payment Details</h1><br><br><br><br>
					<form method ='post' action = 'updateCredit.php' style="background-color:#DDA0DD;
	border-width:25px;
	width:500px;
	text-align:center;
	left:400px;
	position:absolute;
	height:300px;
	opacity :0.5s;
	filter:Alpha(opacity=50);
	top:70%;
	"><br><br><br>
					
					<div style = "text-size: 50px;">
					
					<label>Credit card Id:</label>
					<input type = 'text' name = 'ccid' value = '<?php echo $id?>' required><br><br>
					
					<label>Credit card number:</label>
					<input type = 'text' name = 'ccn' value = '<?php echo $no?>' required><br><br>
					
					<label>Bank:</label>
					<input type = 'text' name = 'bank' value = '<?php echo $bank?>' required><br><br>
					
					<label>Expire date: <label>
					<input type = 'date' name = 'doe' value = '<?php echo $doe?>' required><br><br>
					
					<button type = 'submit' value = 'update'> UPDATE </button>
					
				<div>
			</center>
	</body>

	<footer class="footer-distributed">
					<br><br><br>
					<p>Eventia ! &copy; 2019</p>
					
					<p>207,New road Kandy,<br><br>Sri lanka</p>

					<p>+9481123256</p>

					<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
					
					<p> 
					About Eventia:
					Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
					</p>

	</footer>


	

</html>