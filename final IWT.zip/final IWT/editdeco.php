	<html>
	<head>
	<link rel  = "stylesheet" href="admin.css">
	</head>
	<body>
	<div id = "header" style="height:150px;>
		<?php
		date("y-m-d");
		?>
		
		<img src = "images/images/logo2.jpg" width="100px" height="100px">
		
		<center><img src = "avatar.png" alt = "admin logo" id = "adminlogo" style="top:5%;position:absolute;"></center>
		</div>
		
		<div id = "sidebar">
		</div>
		
		<div id = "data"><br>
	
	
	
	<?php
			require 'config.php';
			
			$recordid=$_GET['ID'];
			
			$sql="SELECT * FROM decoration where ID = $recordid";
			
			$result=$conn->query($sql);
			
			if($result -> num_rows > 0)
			{
				while($row = $result -> fetch_assoc())
				{
					$Deco_name=$row["Decoration"];
					$price= $row["Price"];
					$id =$row["ID"];
					
					
				}
				
				
			}
		
		?>
		<center>
		<form method="post" action="updatedeco.php">
		<div id="form">	
			<h4>Edit Deco Details</h4>
			<br>
			<br>
			<label>  ID</label><br>
			<input type="text" name="id" value=<?php echo $id ?> readonly ><br><br>
		
			<label> Decoration Name</label><br>
			<input type="text" name="dname" value=<?php echo $Deco_name ?> ><br><br>
			
			<label> Price</label><br>
			<input type="text" name="dprice" value=<?php echo $price ?> ><br><br>
			
			
		
			
			<input type="submit" value="Update"> <br><br>
			
		
			
		
		</form>
		</center>
		</div>
		</html>
		
		