	<html>
	<head>
	<link rel  = "stylesheet" href="admin.css">
	</head>
	<body>
	<div id = "header" style="height:150px;>
		<?php
		date("y-m-d");
		?>
		
		<img src = "images/images/logo2.jpg" width="100px" height="100px">
		
		<center><img src = "avatar.png" alt = "admin logo" id = "adminlogo" style="top:5%;position:absolute;"></center>
		</div>
		
		<div id = "sidebar">
		</div>
		
		<div id = "data"><br>
	
	
	
	
	
	<?php
			require 'config.php';
			
			$recordid=$_GET['ID'];
			
			$sql="SELECT * FROM hotel where ID = $recordid";
			
			$result=$conn->query($sql);
			
			if($result -> num_rows > 0)
			{
				while($row = $result -> fetch_assoc())
				{
					$Hotel_name=$row["HotelName"];
					$price= $row["Price"];
					$id =$row["ID"];
					
				}
				
				
			}
		
		?>
		<center>
		<form method="post" action="updatehotels.php">
		<div id="form">	
		<h4>Edit Hotel Details</h4>
		<br>
		<br>
			<label> ID</label>
			<br>
			<input type="text" name="id" value=<?php echo $id ?> readonly><br><br>
		
			<label> Hotel Name</label>
			<br>
			<input type="text" name="hname" value=<?php echo $Hotel_name ?>><br><br>
			
			<label> Price</label>
			<br>
			<input type="text" name="hprice" value=<?php echo $price ?> ><br><br>
			
			
		
			
			<input type="submit" value="Update"> <br><br>
		
			
		
		</form>
		</center>
		