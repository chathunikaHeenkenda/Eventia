<?php
		
		session_start();
		require('config.php');

		
?>

<html>
	<head>
		<title>EVENTIA</title>
		<link rel="stylesheet" href="style/feedback.css">
	</head>
	

		<body>
		
		
			<img src="images/logo.jpg" align="left" width="100px" height="200px">
			<div style="left:94%;position:absolute;top:150px;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "profile" src = "images/profile.png"></a>
			
			
			
			<h1 align="center">eVENTiA</h1>
			
		
			
			<ul id="navi">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
			
			<?php
				require "config.php"; 
			?>
				
				<div class="background">
				
					<div id="div1">
						<p id="p1">Feel free to drop us a line and <br>give us your Feedback</p>
						<p id="p2">We are looking forward to hear back from you</p>
						
					</div>	
					
						<form class="form1" action = "submitFeedback.php" method = "POST">
							
							<label>Name</label><br>
							<input type="text" name="nm"><br><br>
					
							<label>Please write your comments</label><br>
							<textarea placeholder="write something..." name= "cm"></textarea><br><br>
							
							<input type="submit" name="submit" id="submit1" ><br>
						
						</form>
					
				</div>
				
				
				
					
				
					
		
		
			<footer class="footer-distributed">
				<br><br><br><br><br><br>
					<p>Eventia ! &copy; 2019</p>
				
				<div>
					<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
				</div>

				<div>
					<p>+9481123256</p>
				</div>

				<div>
					<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
				</div>

				<p> 
					<span>About Eventia</span>
					Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
				</p>

			</footer>
		
		

	</body>
	
	
	
	</html>