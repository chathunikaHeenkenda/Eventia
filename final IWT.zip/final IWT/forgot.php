<?php
    include 'config.php';
	$result = mysqli_query($conn,"SELECT * FROM user_1");
    
	
if(count($_POST)>0){
	mysqli_query($conn,"UPDATE user_1 SET password='".$_POST['password']."'WHERE Email='".$_POST['Email']."'");
	$message = "Record Modified successfullly";
	
}
else{
	echo "Record Modified unsuccessfullly";
}

$result = mysqli_query($conn,"SELECT password FROM user_1 WHERE Email='".$_GET['Email']."'");
$row=mysqli_fetch_array($result);
?>
    



<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="style/login.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!--add a title-->
	<title>EVENTIA</title>
	
	<script>
	function myFun(){
		var b= document.getElementById("psw").value;
		var c= document.getElementById("c_psw").value;
		
		if(b.length<5){
			document.getElementById("messages").innerHTML="**password must be greater than 5"
			return false;
		}
		
		if(b!=c){
			document.getElementById("messages").innerHTML="**password are not same"
			return false;

		}
		
	}
	</script>
	
</head>
<body>
	<!--add a logo-->
	<div class="topic">
	<img src = "images/logo2.jpg" width="100px" height="100px">
	
	<!--add a header-->
	<h1>EVENTiA</h1>
	</div>
	<!--add a horizantal line-->

	<h2>Login</h2>
	<div class ="login-box" id="testing" 
	
	style="background-color:black;
	top:90%;
	left:40%;
	
	
	
	
	
	
	">
	<img src="images/avatar.png" class="avatar"style="width : 150px;
	height : 150px;
	border-radius : 50%;
	top : -100px;
    left: calc(50% - 50px);
	position:absolute;
	left:180px;">
<body >
<form name="frmUser" method="POST" action="forgot.php"name="myFun"onsubmit="return myFun()">
<div><?php if(isset($message)){echo $message;}?>
  <div class="py-5 opaque-overlay bg-primary">
    <div class="container">
      <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-7">
          <h3 class="text-gray-dark">Forgot Your Password? No Worries</h3>
          <p class="lead mb-4">Complete all the fields below to reset Your Password</p><br><br><br>
          <form class="" method="post" action="forgot.php">
            <div class="form-group">
			
              <input type="text" name="Email"placeholder="Email"size="60" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}" value="<?php echo $row['Email'];?>"required><br><br>
			<input type="password"id="psw" name="password" placeholder="Enter new password"class="form-control"> </div>
			   <input type="password"id="c_psw"name="con-password" placeholder="Confirm password"class="form-control"> </div>
			  
            <div class="form-group">
              <br><br><br><br><br><br><br>
            <input type="submit" value="login" name="submit" style="    border: none;
    outline: none;
    height: 40px;
    background: #006400;
    color: #fff;
    font-size: 18px;
    border-radius: 20px;
"></a><br>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script
			  src="https://code.jquery.com/jquery-3.3.1.js">
			 
  </script>
  
  <div>
		<a href="home.php"><input type="submit" value="Home"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:green;
    color: #fff;
    font-size: 20px;
	width:150px;
	position:absolute;
	left:120%;
	top:10%;"></a><br>
	
	<a href="reserve.php"><input type="submit" value="Revervation"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:green;
    color: #fff;
    font-size: 20px;
	width:150px;
	position:absolute;
	left:120%;
	top:30%;"></a><br>
	
	<a href="contactus.php.php"><input type="submit" value="Contact us"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:green;
    color: #fff;
    font-size: 20px;
	width:150px;
	position:absolute;
	left:120%;
	top:50%;"></a><br>
	
	<a href="aboutus.php"><input type="submit" value="About us"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:green;
    color: #fff;
    font-size: 20px;
	width:150px;
	position:absolute;
	left:120%;
	top:70%;"></a><br>
		</div>
		
</body>

</html>


   