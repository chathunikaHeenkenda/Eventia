<?php
		
		session_start();
		require('config.php');

		
?>



<!DOCTYPE html>
<html>
	<head>
		
		
		<link rel  = "stylesheet" href="style/homestyle.css">
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src ="js/home.js"></script>	
		
		<!--add a title-->
		<title>EVENTIA</title>
		
	
	</head>
	
	<body>
		<!--add a logo-->
		<img id="logo" src = "images/logo2.jpg">
		<a href="reg-delete.php"><input type="submit" value="sign-out"class="btn btn-primary"style="border-radius:1.5rem;border:none;width:150px;background:black;
	font-weight:600;
	color:white;
	margin-top:20px;
	padding:10px;
	top:120px;
	position:absolute;
	left:78%;
	width:200px;
	heigth:200px;"></a><br></a><br>
		<div style="left:94%;position:absolute;top:150px;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
		
		<!--add a header-->
		<h1 id ="eventia">eVENTiA</h1>
		
		<!--add a navigation bar-->
		<form action = "search5.php" method = "POST">

			<input type = "text" name = "search" placeholder = "Search">
			<input type = "submit" value = "search" >
			
		</form>	
	
		<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
		
		
	
	
	
	
	
		<!--chhosing events-->
	
		

		
		<!--Sideshow-->
		<div id="body">
				<div class="body">
					<div id="slideshow">
					
						   <div>
							 <img src="images/image-slider-1.jpg">
						   </div>
						   <div>
							 <img src="images/image-slider-2.jpg">
						   </div>
						   <div>
							 <img src="images/image-slider-3.jpg">
						   </div>
						   <div>
							 <img src="images/image-slider-4.jpg">
						   </div>
						   <div>
							 <img src="images/image-slider-5.jpg">
						   </div>
					</div>
				</div>
			</div>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<h1>WELCOME <?php
		echo $_SESSION['UserName']?></h1><br>
			<h2>Enjoy Offers And Many More.............</h2>
			<h2>Come join your hands with us.............</h2>
	
		
		

	</body>

	<footer class="footer-distributed">
					<br><br><br>
					<p>Eventia ! &copy; 2019</p>
					
					<p>207,New road Kandy,<br><br>Sri lanka</p>

					<p>+9481123256</p>

					<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
					
					<p> 
					About Eventia:
					Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
					</p>

	</footer>


	

</html>