<?php
require 'config.php';
?>
<?php
$FullName = $_POST['FullName'];
$Email = $_POST['Email'];
$UserName = $_POST['UserName'];
$Phone = $_POST['Phone'];
$password = $_POST['password'];
/*$usercheck= $Email;//we check by email
$usercheck= "SELECT * FROM user Where 'Email'='$usercheck'";

$result= $conn ->query($usercheck);
$yes = count($result);

echo $yes;

if($yes>0)
{
	header('location:/website/login.php');
}

else{*/
if(!empty($FullName)||!empty($Email)||!empty($UserName)||!empty($Phone)||!empty($password))
{
	

	
		$SELECT = "SELECT Email from user where email=? Limit 1";
		$mysqli = "INSERT Into user(FullName,Email,UserName,Phone,password) 
					values('$FullName','$Email','$UserName','$Phone','$password')";
		
		
		
		if(mysqli_query($conn,$mysqli))
		{
			echo "<script> alert('succesfully inserted')</script>";

		}
		else
		{
			echo "<script>alert('error')</script>";
		}

	mysqli_close($conn);
}

?>

<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel = "stylesheet" href="style/register.css">
	<link rel = "stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	
	
	<!--add a title-->
	<title>EVENTIA</title>

	<!--add a logo-->
	<div class="topic">
	<img src = "images/logo2.jpg" width="100px" length="200px">
	
	<!--add a header-->
	<h1>EVENTiA</h1>
	</div>
	
	<script>
	function myFun(){
		var b= document.getElementById("psw").value;
		var c= document.getElementById("c_psw").value;
		
		if(b.length<5){
			document.getElementById("messages").innerHTML="**password must be greater than 5"
			return false;
		}
		
		if(b!=c){
			document.getElementById("messages").innerHTML="**password are not same"
			return false;

		}
		
	}
	</script>
</head>	
<body>	
	
		
	<!--add a subheader-->
	<div class="col-md-7 register-right">
		<form method="post" action="register.php" name="myForm" onsubmit="return myFun()">
		<h2>Register Here</h2>
		<div class="register form">
			<div class="form-group"></div>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="Fn" name="FullName"placeholder="Full name" size="60"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="Email" value=""placeholder="Email"size="60" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="Us" name="UserName"placeholder="User Name" size="60"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="PN"value="" placeholder="Phone number" size="60" name="Phone"pattern="[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"id="psw" name="password"placeholder="Password"size="60px"required>
			<span id="messages"></span><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"id="c_psw" name="psw"size="60px" name="confirm"placeholder="confirm password"required><br><br>
			<span id="messages"></span><br><br>	
			<a href="update.php"><input type="submit" value="submit"class="btn btn-primary"></a><br>
			</div>
		</form>
		
	
</body>
<footer class="footer-distributed">
			<br><br><br><br><br><br>
				<p>Eventia ! &copy; 2019</p>
			
			<div>
				<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
			</div>

			<div>
				<p>+9481123256</p>
			</div>

			<div>
				<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
			</div>

			<p> 
				<span>About Eventia</span>
				Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
			</p>

</footer>


</html>
	
	