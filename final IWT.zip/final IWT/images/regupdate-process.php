<?php
require 'config.php';
if(count($_POST)>0){
	mysqli_query($conn,"UPDATE user SET FullName='".$_POST['FullName']."',Email='".$_POST['Email']."',UserName='".$_POST['UserName']."',Phone='".$_POST['Phone']."'WHERE phone='".$_POST['Phone']."'");
	$message = "Record Modified successfullly";
}
$result = mysqli_query($conn,"SELECT * FROM User WHERE Phone='".$_GET['Phone']."'");
$row=mysqli_fetch_array($result);
?>

<html>
<head>
<title>Update User Data</title>
</head>
<body>
<form name="frmUser" method="POST" action="">
<div><?php if(isset($message)){echo $message;}?>
</div>
<div><a href="retrieve.php">User List</a>
</div>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="Fn" name="FullName"placeholder="Full name" size="60"value="<?php echo $row['FullName'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="Email"placeholder="Email"size="60" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}" value="<?php echo $row['Email'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="Us" name="UserName"placeholder="User Name" size="60"value="<?php echo $row['UserName'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="PN"value="" placeholder="Phone number" size="60" name="Phone"pattern="[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"value="<?php echo $row['Phone'];?>"  required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"id="psw" name="password"placeholder="Password"size="60px"value="<?php echo $row['password'];?>" required>
			<span id="messages"></span><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"id="c_psw" name="psw"size="60px" name="confirm"placeholder="confirm password"required><br><br>
			<span id="messages"></span><br><br>	
			<a href="home.html"><input type="submit" value="submit"class="btn btn-primary"></a><br>

</form>
</body>
</html>