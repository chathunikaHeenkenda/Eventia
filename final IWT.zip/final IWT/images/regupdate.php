<?php
require 'config.php';
$result = mysqli_query($conn,"SELECT * FROM User");
?>

<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" href="regupdate.css">
<title>Update User Details</title>
</head>

<body>
<table border="1" width="100%">
<tr>
<td>Full Name</td>
<td>Email</td>
<td>User Name</td>
<td>Phone Number</td>
<td>Password</td>
<td>Action</td>

<?php
$i=0;
while($row = mysqli_fetch_array($result)){
	if($i%2==0)
		$classname = "even";
	else
		$classname = "odd";
	?>
	<tr class="<?php if(isset($classname)) echo $classname;?>">
	<td><?php echo $row["FullName"]; ?></td>
	<td><?php echo $row["Email"]; ?></td>
	<td><?php echo $row["UserName"]; ?></td>
	<td><?php echo $row["Phone"]; ?></td>
	<td><?php echo $row["password"]; ?></td>
	<td><a href="regupdate-process.php?Phone=<?php echo $row["Phone"];?>">Update</a></td>
	</tr>
	
	<?php
	$i++;
}
	?>	

</table>
</body>
</html>