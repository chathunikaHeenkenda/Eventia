function loadData(data)
{
	if(data == "btn1")
	{
		document.getElementById("para1").innerHTML="Offers :  25% discount on totalbill from these selected hotels ,15% discount from the Photographers,10% from refreshments ,5% from cakes....";
	}
	else if(data == "btn2")
	{
		document.getElementById("para1").innerHTML="We have planned more than 200 anniversaries this year...Come join your hands with us";
	}

		
}