$("#slideshow > div:gt(0)").hide();

setInterval(function() {
  $('#slideshow > div:first')
    .fadeOut(1000)
    .next()
    .fadeIn(1000)
    .end()
    .appendTo('#slideshow');
}, 3000);

/*var slideIndex =0;
carousel();

function carousel()
{
	var i;
	var x=document.getElementByClassName("mySlides");
	
	for(i=0;i<x.length;i++)
	{
		x[i].style.display="none";
	}
	
	slideIndex++;
	
	if(slideIndex>x.length)
	{slideIndex=1}
	x[slideIndex-1].style.display="block";
	setTimeout(carousal,2000);
	
	
	
}*/