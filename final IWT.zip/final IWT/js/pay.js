function calc(){
	var hotel = document.getElementsByName("hotp").value;
	var car = document.getElementsByName("carp").value;
	var dec = document.getElementsByName("decp").value;
	var scharge = document.getElementsByName("scharge").value;
	
	var etot = hotel + car + dec;
	
	document.getElementsByName('etot').innerHTML = etot;
	
	var tot = etot + scharge;
	
	document.getElementsByName('tot').innerHTML = tot;
	
}