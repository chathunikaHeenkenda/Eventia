
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="style/login.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!--add a title-->
	<title>EVENTIA</title>
	
</head>
<body>
	<!--add a logo-->
	<div class="topic">
	<img src = "images/logo2.jpg" width="100px" height="100px">
	
	<!--add a header-->
	<h1>EVENTiA</h1>
	</div>
	<!--add a horizantal line-->

	<h2>Admin Login</h2>
	<div class ="login-box" id="testing" 
	
	style="background-color:black;
	width : 500px;
	height : 500px;
	background:black;
	top : 85%;
	left : 30%;
	position : absolute;
	Box-sizing : boarder-box;
	padding:50px 20px;
	margin-bottom:10%;
	opacity:0.8;
	color:white;">
	
	
	
	
	
	
	<img src="images/avatar.png" class="avatar"
	<!--add a subheader-->
	<form method="POST" action="login2.php">
	<div>
	<h2>Admin login</h2>
	<br>
	<label>Email :</label>
	<input type="text" placeholder="put your Email" name="Email" required><br><br>
	
	<label>Password :</label>
	<input type="password"id="psw"placeholder="put your password" name="password"size="70px" required>
	<br><br><br><br><br><br>
	
	<input type="submit" value="login" name="submit" style="    border: none;
    outline: none;
    height: 40px;
    background: #006400;
    color: #fff;
    font-size: 18px;
    border-radius: 20px;
"></a><br>
	</br>
	<div id="container">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="forgot.php" style="margin-right:0px;font-size:13px;font-family:tahoma,senava,sans-serif;">Reset password</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="forgot.php" style="margin-right:0px;font-size:13px;font-family:tahoma,senava,sans-serif;">Forgot password</a>
	</div><br><br><br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Don't have account?<a href="register.php"style="font-color:white">&nbsp;Sign Up</a>
	</form>
	
	
	<div class ="login-box" id="testing" 
	
	style="background-color:black;
	width : 500px;
	height : 500px;
	background:black;
	top : 50%;
	left : 170%;
	position : absolute;
	Box-sizing : boarder-box;
	padding:50px 20px;
	margin-bottom:10%;
	opacity:0.8;
	color:white;">
	
	
	
	
	
	
	<img src="images/avatar.png" class="avatar"
	<!--add a subheader-->
	<form method="POST" action="login1.php">
	<div>
	<h2>User login</h2>
	<br>
	<label>Email :</label>
	<input type="text" placeholder="put your Email" name="Email" required><br><br>
	
	<label>Password :</label>
	<input type="password"id="psw" name="password"size="70px" required>
	<br><br><br><br><br><br>
	
	<input type="submit" value="login" name="submit" style="    border: none;
    outline: none;
    height: 40px;
    background: #006400;
    color: #fff;
    font-size: 18px;
    border-radius: 20px;
"></a><br>
	</br>
	<div id="container">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="forgot.php" style="margin-right:0px;font-size:13px;font-family:tahoma,senava,sans-serif;">Reset password</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="forgot.php" style="margin-right:0px;font-size:13px;font-family:tahoma,senava,sans-serif;">Forgot password</a>
	</div><br><br><br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Don't have account?<a href="register.php">&nbsp;Sign Up</a>
	</form>


	</body>
	
	<footer class="footer-distributed"style="position:absolute;
	background-color:black;
	color:white;
	bottom:0;
	width:300%;
	height:40%;
	left:-160%;
	top:800px;
	text-align:center;">
			<br><br><br><br><br><br>
			<div>
				<p>Eventia ! &copy; 2019</p>
			</div>
			<div>
				<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
			</div>

			<div>
				<p>+9481123256</p>
			</div>

			<div>
				<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
			</div>

			<p> 
				<span>About Eventia</span>
				Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
			</p>



	
</html>	