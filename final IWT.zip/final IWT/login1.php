

<?php
require 'config.php';

session_start();

$Email=$_POST["Email"];
$password=$_POST["password"];
	
$sql="SELECT * FROM user_1";

$result=$conn->query($sql);

if($result->num_rows>0)
{
	while($row=$result->FETCH_ASSOC())
	{
		if($_POST['Email']==$row['Email'] && $_POST['password']==$row['password'])
			
		{
			$_SESSION['user_id']=$row['user_id'];
			$_SESSION['Email']=$row['Email'];
			$_SESSION['FullName']=$row['FullName'];
			$_SESSION['UserName']=$row['UserName'];
			$_SESSION['Phone']=$row['Phone'];
			$_SESSION['password']=$row['password'];
			
			
			header ("Location:home.php");
			
		}
		
		/*if($_POST['Email']!=$row['Email'] && $_POST['password']!=$row['paasword'])
		{
			header ("Location:login.php");
		}*/
	}
}
	
	
/*if($row==1){

		echo "your Email and password correct";
		header('location:profile.php');
		
		$sql = "SELECT * FROM user_1";

		$result = $conn->query($sql);
		if($result->num_rows>0)
	{
	while($row=$result->FETCH_ACCOS())
	{
		if($_POST['Email']==$row['Email'] && $_POST['password']==$row['paasword'])
		{
			$_SESSION['Email']=$row['Email'];
			$Email=$row['Email'];
			$_SESSION['FullName']=$row['FullName'];
			
		}
	}
		
	
	
	
	

}
}
	else{
		echo "your Email and password  wrong";
	}
	
}*/
?>