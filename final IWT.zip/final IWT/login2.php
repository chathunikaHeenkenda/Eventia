<?php
require 'config.php';

session_start();

$Email="admin@gmail.com";
$password="admin123";
	
$sql="SELECT * FROM user_1";

$result=$conn->query($sql);

if($result->num_rows>0)
{
	while($row=$result->FETCH_ASSOC())
	{
		if($_POST['Email']=="admin@gmail.com" && $_POST['password']=="admin123")
			
		{
			$_SESSION['user_id']=$row['user_id'];
			$_SESSION['Email']=$row['Email'];
			$_SESSION['FullName']=$row['FullName'];
			$_SESSION['UserName']=$row['UserName'];
			$_SESSION['Phone']=$row['Phone'];
			$_SESSION['password']=$row['password'];
			
			
			header ("Location:admin.php");
			
		}
	}
}	
?>