<?php
		
		session_start();
		require('config.php');

		
?>


<!DOCTYPE html>
<html>
	<head>
		
		
		<link rel  = "stylesheet" href="style/homestyle.css">
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>	
		
		<!--add a title-->
		<title>EVENTIA</title>
		
	
	</head>
	
	<body>
		<!--add a logo-->
		<img id="logo" src = "images/logo2.jpg">
		<div style="left:94%;position:absolute;top:120px;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
		
		<!--add a header-->
		<h1 id ="eventia">eVENTiA</h1>
		
		<!--add a navigation bar-->
	
		<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
		
			<?php
				$recordId = $_GET['id'];
				
				$sql = "SELECT * FROM reservation WHERE EventNo = $recordId";
				
				$result = $conn->query($sql);
				
				
				if($result->num_rows>0)
				{
					//take specific each row data to variable_according to the id
					while($row = $result ->fetch_assoc())
					{
						$id = $row['EventNo'];
						$Event_type = $row['Event_type'];
						
						$date = $row['Date'];
						$time = $row['Time'];
						$theme = $row['Theme'];
						$phone = $row['Phone'];
						$hotel = $row['Hotel'];
						$decoration= $row['Decoration'];
						$car = $row['Car'];
						$Number_of_visitors = $row['No_of_visitors'];
					}
				}
				else{
					echo "no records";
				}
				
				$sql = "SELECT Price FROM reservation r, hotel h WHERE r.Hotel = h.HotelName and EventNo = $recordId";
				
				$result = $conn->query($sql);
				
				
				if($result->num_rows>0)
				{
					//take specific each row data to variable_according to the id
					while($row = $result ->fetch_assoc())
					{
						$hprice = $row['Price'];
					}
				}
				else{
					echo "no records";
				}
				
				$sql = "SELECT Price FROM reservation r, car c WHERE r.Car = c.Car and EventNo = $recordId";
				
				$result = $conn->query($sql);
				
				
				if($result->num_rows>0)
				{
					//take specific each row data to variable_according to the id
					while($row = $result ->fetch_assoc())
					{
						$cprice = $row['Price'];
					}
				}
				else{
					echo "no records";
				}
				
				$sql = "SELECT Price FROM reservation r, decoration d WHERE r.Decoration = d.Decoration and EventNo = $recordId";
				
				$result = $conn->query($sql);
				
				
				if($result->num_rows>0)
				{
					//take specific each row data to variable_according to the id
					while($row = $result ->fetch_assoc())
					{
						$dprice = $row['Price'];
					}
				}
				else{
					echo "no records";
				}
				
				$etot = $hprice + $cprice + $dprice;
				
				$tot = 40000 + $etot;
		?>
		
			
			
	<h1 align = 'center'>Payment</h1><br><br><br><br><br><br>
	<div align = 'center'>
	
	<form method ='post' action = 'creditCard.php' style="background-color:#DDA0DD;
	border-width:25px;
	width:500px;
	text-align:center;
	left:400px;
	position:absolute;
	height:550px;
	opacity :0.5s;
	filter:Alpha(opacity=50);
	top:60%;
	"><br><br><br>
	<label>User ID:</label>
	<input type = 'text' name = 'number' value = '<?php echo $phone?>' disabled><br><br>
	<label>Event number:</label>
	<input type = 'text' name = 'eno' value = '<?php echo $id?>' disabled><br><br>
	<label>Hotel:</label>
	<input type = 'text' name = 'hot' value = '<?php echo $hotel?>' disabled>
	<input type = 'text' name = 'hotp' value = '<?php echo $hprice?>' disabled><br><br>
	<label>Decoration:</label>
	<input type = 'text' name = 'dec' value = '<?php echo $decoration?>' disabled>
	<input type = 'text' name = 'decp' value = '<?php echo $dprice?>' disabled><br><br>
	<label>Car:<label>
	<input type = 'text' name = 'car' value = '<?php echo $car?>' disabled>
	<input type = 'text' name = 'carp' value = '<?php echo $cprice?>' disabled><br><br>
	<hr><br><br>
	<label>Total amount payable for the event:</label>
	<input type = 'text' name = 'etot' value = '<?php echo $etot?>' disabled><br><br>
	<label>Service charge:</label>
	<input type = 'text' name = 'scharge' value = '40000' disabled><br><br><br><br>
	<hr><br>
	<label>Total amount:</label>
	<input type = 'text' name = 'tot' value = '<?php echo $tot?>' disabled><br><br><br><br>
	
	<button name = 'button'><a href = 'creditCard.php'style="width:200px;">PAY</a></button>
	
	
	
	</form>	
	</div>
	</body>

	<footer class="footer-distributed">
					<br><br><br>
					<p>Eventia ! &copy; 2019</p>
					
					<p>207,New road Kandy,<br><br>Sri lanka</p>

					<p>+9481123256</p>

					<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
					
					<p> 
					About Eventia:
					Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
					</p>

	</footer>


	

</html>