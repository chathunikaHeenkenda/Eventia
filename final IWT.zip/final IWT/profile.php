
<!DOCTYPE html>
<html>
	<head>
		
		
		<link rel  = "stylesheet" href="style/homestyle.css">
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src ="js/home.js"></script>	
		
		<!--add a title-->
		<title>EVENTIA</title>
		
	
	</head>
	
	<body style="background-color:white;">
		<!--add a logo-->
		<img id="logo" src = "images/logo2.jpg">
		
		<a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
		
		<!--add a header-->
		<h1 id ="eventia">eVENTiA</h1>
		
		<!--add a navigation bar-->
	
		<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
		<h2 style="text-align:center;font-size:40px;">My profile</h2>
		<form method="POST" action="" class="box"style="width : 500px;
	height : 500px;
	background:#00396c;
	top : 50%;
	left : 32%;
	position : absolute;
	Box-sizing : boarder-box;
	padding:50px 20px;
	margin-bottom:10%;
	opacity:0.8;
	color:white;
	font-size:20px;">
		<img id= "avatar" src = "images/avatar.png"style="text-align:center;position:absolute;left:43%;top:10%;"></a>
		<br><br><br><br><br><br><br><br>
		<div style="text-align:center;">
		<?php
		session_start();
		
		echo "User Id :".str_repeat('&nbsp;',3) .$_SESSION['user_id']."<br><br>";
		echo "Full Name :".str_repeat('&nbsp;',3) .$_SESSION["FullName"]."<br><br>";
		echo "User Name :".str_repeat('&nbsp;',3)  .$_SESSION["UserName"]."<br><br>";
		echo "Email :".str_repeat('&nbsp;',3)  .$_SESSION["Email"]."<br>"."<br>";
		echo "Phone Number :".str_repeat('&nbsp;',3)  .$_SESSION["Phone"]."<br><br>";
		echo "Password :".str_repeat('&nbsp;',3)  .$_SESSION["password"]."<br><br>";
		
		
		
				
		?>
		<button type="submit" style="border-radius:1.5rem;border:none;width:150px;background:#f8f8f8;
	font-weight:600;
	color:blue;
	margin-top:20px;
	padding:10px;
	top:80%;
	position:absolute;
	left:38%;"><a href="Editprofile.php?user_id=<?php echo $_SESSION["user_id"];?>">Edit</button>
		</form>