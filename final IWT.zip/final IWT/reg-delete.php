<?php
require 'config.php';
$result = mysqli_query($conn,"SELECT * FROM User_1");
?>

<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" href="regupdate.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Eventia</title>
</head>

<body>
<!--add a logo-->
	<div class="topic"style="background-color:black;
	height:100px;">
	<img src = "images/logo2.jpg" width="100px" length="200px">
	<br><br>
	<!--add a horizantal line-->
<table border="1" width="100%"style="background-color:pink">
<tr>
<td>Full Name</td>
<td>Email</td>
<td>User Name</td>
<td>Action</td>

<?php
$i=0;
while($row = mysqli_fetch_array($result)){
	if($i%2==0)
		$classname = "even";
	else
		$classname = "odd";
	?>
	<tr class="<?php if(isset($classname)) echo $classname;?>">
	<td><?php echo $row["FullName"]; ?></td>
	<td><?php echo $row["Email"]; ?></td>
	<td><?php echo $row["UserName"]; ?></td>
	<td><a href="regdelete-process.php?user_id=<?php echo $row["user_id"];?>"style=" border: none;
    outline: none;
    height: 80px;
    background:blue;
    color: #fff;
    font-size: 15px;
	">Delete</a></td>
	</tr>
	
	<?php
	$i++;
}
	?>	

</table>
</body>
</html>