<?php
require 'config.php';
if(count($_POST)>0){
	mysqli_query($conn,"DELETE FROM user_1 WHERE Email='".$_POST['Email']."'");
	$message = "DELETE successfullly";
	header('location:default.php');
}

$result = mysqli_query($conn,"SELECT * FROM User_1 WHERE user_id='".$_GET['user_id']."'");
$row=mysqli_fetch_array($result);
?>

<html>
<head>
<title>Eventia</title>

<script>
	function myFun(){
		var b= document.getElementById("psw").value;
		var c= document.getElementById("c_psw").value;
		
		
		if(b!=c){
			document.getElementById("messages").innerHTML="**password are not same"
			return false;

		}
		
	}
	</script>
</head>
<body>
<!--add a logo-->
	<div class="topic"style="background-color:black;
	height:100px;">
	<img src = "images/logo2.jpg" width="100px" height="100px">
	<br><br><br><br>
<div class ="login-box" id="testing" 
	
	style="background-color:pink;
	text-align:center;
	top:500px;
	postion:absolute;"
	</div>
	
<form name="frmUser" method="POST" action="" onsubmit="return myFun();">
<div><?php if(isset($message)){echo $message;}?>
</div>
<div>User List</a><br><br>
</div>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="Fn" name="FullName"placeholder="Full name" size="60"value="<?php echo $row['FullName'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="Email"placeholder="Email"size="60" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}" value="<?php echo $row['Email'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="Us" name="UserName"placeholder="User Name" size="60"value="<?php echo $row['UserName'];?>"required><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"id="psw" name="password"placeholder="Password"size="60px"value="<?php echo $row['password'];?>" required>
			<span id="messages"></span><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"id="c_psw" name="psw"size="60px" name="confirm"placeholder="confirm password"required><br><br>
			<span id="messages"></span><br><br>	
			<input type="submit" value="sign out"class="btn btn-primary"style="border: none;
    outline: none;
    height: 50px;
    background:blue;
    color: #fff;
    font-size: 20px;
    border-radius: 20px;
	width:100px"></a><br>

</form>
</body>
</html>