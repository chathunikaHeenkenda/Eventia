<?php
require 'config.php';
?>
<?php 
$user_id = $_POST[''];
$FullName = $_POST['FullName'];
$UserName = $_POST['UserName'];
$Email = $_POST['Email'];
$Phone = $_POST['Phone'];
$password = $_POST['password'];
/*$usercheck= $Email;//we check by email
$usercheck= "SELECT * FROM user Where 'Email'='$usercheck'";

$result= $conn ->query($usercheck);
$yes = count($result);

echo $yes;

if($yes>0)
{
	header('location:/website/login.php');
}

else{*/
if(!empty($FullName)||!empty($UserName)||!empty($Email)||!empty($Phone)||!empty($password))
{
	$user = mysqli_query($conn,"SELECT Email FROM user_1 where Email='$Email'");
		$result = mysqli_num_rows($user);
	if($result>0){
	$msg = "This Email already in used please choose different email";
	}


	else{

	
		$SELECT = "SELECT Email from user_1 where email=? Limit 1";
		$mysqli = "INSERT Into user_1(user_id,FullName,UserName,Email,Phone,password) 
					values('','$FullName','$UserName','$Email','$Phone','$password')";
		
		
		
		if(mysqli_query($conn,$mysqli))
		{
			echo "<script> alert('succesfully inserted')</script>";
			header('location:login.php');

		}
		else
		{
			echo "<script>alert('error')</script>";
		}
	}	
}
?>

<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel = "stylesheet" href="style/register.css">
	<link rel = "stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	
	
	<!--add a title-->
	<title>EVENTIA</title>

	<!--add a logo-->
	<div class="topic"style="background-color:black;
	height:100px;
	position:absolute;
	top:0;
	width:1550px;">
	<img src = "images/images/logo2.jpg" width="100px" height="100px">
	
	<!--add a header-->
	<h1 style="margin : 0;
	padding	: 0 0 20px;
	font-size : 60px;
	text-align : center;
	color:white;
	top:6%;
	position:absolute;
	left:40%;
	">eVENTiA</h1>
	</div>
	
	<script>
	function myFun(){
		var b= document.getElementById("psw").value;
		var c= document.getElementById("c_psw").value;
		
		if(b.length<5){
			document.getElementById("messages").innerHTML="**password must be greater than 5"
			return false;
		}
		
		if(b!=c){
			document.getElementById("messages").innerHTML="**password are not same"
			return false;

		}
		
	}
	</script>
</head>	
<body ">	
	<div class="container">
	<div class="row">
	<div class="col-md-10 offset=md-1">
	<div class=""row">
		<div class="col-md-5"style="text-align:center;
	color:black;
	padding:50px;
	position:absolute;
	left:-5%;
	top:10%;
	font-size:50px;
	background-color:orange;
	height:500px;
	width:1000%;">
			<h3>Join us</h3>
			<p>Welcome to  Eventia</p>
			<a href="aboutus.php"><button type="button" class="btn btn-primary"style="border-radius:1.5rem;
	border:none;
	width:120px;
	background:#f8f8f8;
	font-weight:600;
	color:black;
	margin-top:20px;
	padding:10px;
	top:80%;
	position:absolute;
	left:35%;
	background:blue;	">About us</button></a>
		</div>	
	
		
	<!--add a subheader-->
	<?php
		if(isset($_POST['submit'])){
			$FullName = $_POST['FullName'];
			$UserName = $_POST['UserName'];
			$Email = $_POST['Email'];
			$Phone = $_POST['Phone'];
		}
		?>
		<div class="col-md-7 register-right" style="border:none;
	background:gray;
	border-top-left-radius:10% 50%;
	border-bottom-left-radius:10% 50%;
	padding:50px;
	left:50%;
	width:1200px;
	top:10%;">
		<form method="post" action="register.php" name="myForm" onsubmit="return myFun()"style="width:500px;">
		<h2>Register Here</h2>
		<center><div class="register form"style="padding:30px;width:500px;">
		<div><?php if(isset($msg)){echo $msg;}?>
			<div class="form-group"style="width:1000px;"></div>
			
			<input type="text" id="Fn" name="FullName"placeholder="Full name" size="50"required><br><br>
			<input type="text" id="Us" name="UserName"placeholder="User Name" size="50"required><br><br>
			<input type="text" name="Email" value=""placeholder="Email"size="50" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}"required><br><br>
			<input type="text" id="PN"value="" placeholder="Phone number" size="50" name="Phone"pattern="[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"required><br><br>
			<input type="password"id="psw" name="password"placeholder="Password"size="50px"required>
			<span id="messages"></span><br><br>
			<input type="password"id="c_psw" name="psw"size="50px" name="confirm"placeholder="confirm password"required><br><br>
			<span id="messages"></span><br><br>	
			<a href="update.php"><input type="submit" value="submit"class="btn btn-primary"style="border-radius:1.5rem;border:none;width:150px;background:#f8f8f8;
	font-weight:600;
	color:blue;
	margin-top:20px;
	padding:10px;
	top:70%;
	position:absolute;
	left:38%;"></a><br></a><br>
			</div>
			</center>
			</div>
		</form>
		
		
		
		
	
</body>

<footer class="footer-distributed"style="
	position:absolute;
	background-color:black;
	color:white;
	bottom:0;
	width:300%;
	height:80%;
	left:-100%;
	top:800px;
	text-align:center;
	
">
			<br><br><br><br><br><br>
				<p>Eventia ! &copy; 2019</p>
			
			<div>
				<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
			</div>

			<div>
				<p>+9481123256</p>
			</div>

			<div>
				<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
			</div>

			<p> 
				<span>About Eventia</span>
				Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
			</p>

</footer>
-->


</html>
	
	