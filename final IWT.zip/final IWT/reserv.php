<?php
		require 'config.php';
		session_start();

		
?>


<!DOCTYPE html>
<html>
	<head>
		<link rel  = "stylesheet" href="style/annistyle.css">
		<!--add a title-->
		<title>EVENTIA</title>
		
	</head>
	
	<body>
		<!--add a logo-->
		<img id="logo" src = "images/logo2.jpg">
		
		<div style="left:95%;position:absolute;top:17%;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
		
		<!--add a header-->
		<h1 id="eventia">eVENTiA</h1>
		<!--navigation bar-->
		<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.html">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
		
	
		

		<h3 id="reg">FORM </h3>
		
		<form method = "post" action = "reserveAdd.php">
		
			<div id="form">
			
				

				<label class="name">Select Event</label><br>
				<select name="event">
				<option value = "Hotel">Select one</option>
				<option value = "Wedding">Wedding</option>
				<option value = "Birthday party">Birthday party</option>
				<option value = "Meetings & Conferences">Meetings & Conferences</option>
				</select><br><br>
				
				<label class="name">Enter date</label><br>
				<input type ="date" name="date1"><br><br>
				
				<label class="name">Enter Starting Time</label><br>
				<input type ="text" name= "time"><br><br>
				
				
				<label class="name">Select the Hotel You Prefer </label><br>
				<select name ="hotel">
				<option value = "selecthotel">Select one</option>
				<option value = "None">None</option>
				<option value = "Tree of life">Tree of life- price 100000 per day</option>
				<option value = "Cinnamon Citadel">Cinnamon Citadel - price 200000 per day</option>
				<option value = "Amaya Hills">Amaya Hills- price- 300000 per day</option>
				<option value = "Earls Regency">Earls Regency- price 400000 per day</option>
				<option value = "Mahaweli Reach ">Mahaweli Reach-price 500000 per day</option>

				</select><br><br>
				
				<label class="name">Select the Decoration</label> <br>
				<select name ="deco">
				<option value = "selectdeco">Select one</option>
				<option value = "None">None</option>
				<option value = "Creative flora">Creative flora- Price 10000per day</option>
				<option value = "Micro Flora">Micro Flora-Price 30000per day</option>
				<option value = "Neranjan Flora">Neranjan Flora-Price 40000per day</option>
				<option value = "Lassana flora">Lassana flora-Price 50000per day</option>
				<option value = "Flower Sense">Flower Sense-Price 60000per day</option>
				
				</select><br><br>
				
				<label class="name">Select the car</label> <br>
				<select  name ="car">
				<option value = "selectcar">Select one</option>
				<option value = "None">None</option>
				<option value = "Toyota Premio">Toyota Premio- Price 1000per day</option>
				<option value = "Toyota Axio">Toyota Axio-Price 2000per day</option>
				<option value = "Toyota Corolla">Toyota Corolla-Price 3000per day</option>
				<option value = "Audi">  Audi-Price 4000per day</option>
				<option value = "Benz"> Benz- 5000per day</option>
				
				</select><br><br>
				
			
			
			
			
			<label class="name">Number of visitors</label><br>
			<select name="no_of_visit">
			<option value = "selectvisitors">select one</option>
			<option value = "10-50">10-50</option>
			<option value = "51-100">51-100</option>
			<option value = "101-150">101-150</option>
			<option value = "151-200">151-200</option>
			<option value = "200 and above">200 and above</option>
			</select><br><br>
			
			
			<label class="name">Theme</label><br>
			<input type = "text" name = "theme" required><br><br>
			
			
			<label class="name">Enter User_id</label><br>
			<input type = "text" name = "phone" value="<?php echo $_SESSION['user_id'];?>"><br><br>
			
			
			<input type = "checkbox" id ="chk" class = "radiostyle"  required>
			<label style = "color:white;"> Accept privacy policy and terms</label><br><br>
			<input type ="submit" id ="btnsubmit" class ="inputbutton" value="submit"required><br><br>
			

				
				

				
			</div>
		
		</form>

	</body>
	
	<footer class="footer-distributed">
						<br><br><br>
						<p>Eventia ! &copy; 2019</p>
						
						<p>207,New road Kandy,<br><br>Sri lanka</p>

						<p>+9481123256</p>

						<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
						
						<p> 
						About Eventia:
						Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
						</p>

	</footer>

</html>