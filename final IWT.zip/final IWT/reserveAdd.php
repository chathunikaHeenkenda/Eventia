<?php

require 'config.php';

	
	$Event_type = $_POST['event'];
	$date = $_POST['date1'];
	$time = $_POST['time'];
	$theme = $_POST['theme'];
	$phone = $_POST['phone'];
	$hotel = $_POST['hotel'];
	$decoration= $_POST['deco'];
	$car = $_POST['car'];
	$Number_of_visitors = $_POST['no_of_visit'];
	
	$sql = "INSERT INTO reservation(EventNo, Event_type, Date, Time, Theme,Phone, Hotel, Decoration, Car, No_of_visitors) 
	       VALUES('', '$Event_type','$date','$time','$theme','$phone','$hotel','$decoration','$car','$Number_of_visitors')";
	
	if(mysqli_query($conn,$sql))
		{
			//"<script> alert('succesfully inserted')</script>";
			header('Location: index.php');

		}
		else
		{
			//"<script>alert('error')</script>";
		}
		
		
		

	mysqli_close($conn);
?>


<!--<!DOCTYPE html>
<html>
	<head>
		<link rel  = "stylesheet" href="style/annistyle.css">
		<!--add a title
		<title>EVENTIA</title>
		
	</head>
	
	<body>
		
		<img id="logo" src = "images/logo2.jpg">
		
		<img id= "avatar" src = "images/avatar.png">
		
		
		<h1 id="eventia">eVENTiA</h1>
		
		<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.html">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="index.php" id="big">Cancel Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
		</ul>
		
		<h2 style="text-align:center;">Your reservation is as follow</h2>
			<center>
			<div>
			<form method = 'post' action = 'payment.php'>
				<table border ="5" style="width:100%;">
					<tr>
					<th>Event Type</th>
					<th>Date</th>
					<th>Time</th>
					<th>Theme</th>
					<th>Phone</th>
					<th>Hotel</th>
					<th>Decoration</th>
					<th>Car</th>
					<th>Number of visitors</th>
	
					</tr>
					

	
					
					<tr>
						<td><?php //echo $Event_type?></td>
						<td><?php// echo $date?></td>
						<td><?php //echo $time?></td>
						<td><?php //echo $theme?></td>
						<td><?php //echo $phone ?></td>
						<td><?php //echo $hotel ?></td>
						<td><?php //echo $decoration?></td>
						<td><?php// echo $car?></td>
						<td><?php //echo $Number_of_visitors?></td>
						
						
					</tr>
					</form>
			</div>
			</center>
			
			
			<button style='top:500px;position:absolute;left:600px;' type='submit'><a href='payment.php?id=$id'>Click Here For Payments</a></button>
			
			
	
			

				
				

				
		

	</body>
	
	<footer class="footer-distributed">
						<br><br><br>
						<p>Eventia ! &copy; 2019</p>
						
						<p>207,New road Kandy,<br><br>Sri lanka</p>

						<p>+9481123256</p>

						<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
						
						<p> 
						About Eventia:
						Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
						</p>

	</footer>

</html>