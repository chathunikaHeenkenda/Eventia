
<?php

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "eventia";


//creating the connection

$conn = new mysqli($servername , $username , $password , $databasename);

//checking the connection

if($conn -> connect_error)
{
die("Connection Failed:".$conn->connect_error);
}

else
{
echo "Connected Succesfully";
}


$sql = "SELECT Name ,Price, Description FROM hsearch LIMIT 25";
$results = $conn->query($sql);
$tableContent = '';

$sql1 = "SELECT Name ,Price, Description FROM deco LIMIT 25";
$results = $conn->query($sql1);
$tableContent = '';

$sql2 = "SELECT Name ,Price, Description FROM vsearch LIMIT 25";
$results = $conn->query($sql2);
$tableContent = '';



	foreach ($results as $result){

    	$tableContent = $tableContent.'<tr>'.
	            '<td>'.$result['Name'].'</td>'
	            .'<td>'.$result['Price'].'</td>'
	            .'<td>'.$result['Description'].'</td>';
	}

if(isset($_POST['search'])){
	$searchKeyWord = $_POST['search'];
	$tableContent= '';
    if($searchKeyWord!=''){
    	$sql = "SELECT Name,Price, Description FROM hsearch where Name LIKE '%".$searchKeyWord."%'";
    } else{
    	$sql = "SELECT Name,Price, Description  FROM  hsearch LIMIT 25";
    }
	
	$results = $conn->query($sql);

    foreach ($results as $result){

    	$tableContent = $tableContent.'<tr>'.
	            '<td>'.$result['Name'].'</td>'
	            .'<td>'.$result['Price'].'</td>'
	            .'<td>'.$result['Description'].'</td>';
	}
	
	
	if($searchKeyWord!=''){
    	$sql1 = "SELECT Name,Price, Description FROM vsearch where Name LIKE '%".$searchKeyWord."%'";
    } else{
    	$sql1= "SELECT Name,Price, Description  FROM vsearch LIMIT 25";
    }
	
	
	$results = $conn->query($sql1);

    foreach ($results as $result){

    	$tableContent = $tableContent.'<tr>'.
	            '<td>'.$result['Name'].'</td>'
	            .'<td>'.$result['Price'].'</td>'
	            .'<td>'.$result['Description'].'</td>';
	}
	
	if($searchKeyWord!=''){
    	$sql2 = "SELECT Name,Price, Description FROM deco where Name LIKE '%".$searchKeyWord."%'";
    } else{
    	$sql2 = "SELECT Name,Price, Description  FROM deco LIMIT 25";
    }
	
$results = $conn->query($sql2);

    foreach ($results as $result){

    	$tableContent = $tableContent.'<tr>'.
	            '<td>'.$result['Name'].'</td>'
	            .'<td>'.$result['Price'].'</td>'
	            .'<td>'.$result['Description'].'</td>';
	}
    



	
}

?>








<html>
<head>
<title>EVENTIA</title>
<link rel="stylesheet" href="style/feedback.css">
</head>


<body>


<img src="images/logo.jpg" align="left" width="100px" length="200px">
<img id="profile" src="images/profile.png">

<h1 align="center">eVENTiA</h1>

<hr>

		<ul id="navi">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.html">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
		</ul>

<form action = "search5.php" method = "POST">

<input type = "text" name = "search" placeholder = "Search">
<input type = "submit" value = "search" >



<table border="1">
	<thead>
		<tr >
			<th>Name</th>
			<th>Price</th>
			<th>Description</th>
		</tr>
	</thead>
	<tbody>
		<?php
                
	        echo $tableContent;
	        
	    ?>
	</tbody>
</table>


</form>



<footer class="footer-distributed">
<br><br><br><br><br><br>
<p>Eventia ! &copy; 2019</p>

<div>
<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
</div>

<div>
<p>+9481123256</p>
</div>

<div>
<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
</div>

<p>
<span>About Eventia</span>
Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
</p>

</footer>



</body>



</html>