<html>
	<head>
		<title>EVENTIA</title>
		<link rel="stylesheet" href="style/feedback.css">
	</head>
	

		<body>
	
			<img src="images/logo.jpg" align="left" width="100px" length="200px">
			<img id="profile" src="images/profile.png">
			
			<h1 align="center">eVENTiA</h1>
			
			<hr>
			
			<ul id="navi">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.html">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
		</ul>
			
					
							
					
			
			<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$databasename = "eventia";
	
					//creating the connection
	
					$conn = new mysqli($servername , $username , $password , $databasename);
		
					//checking the connection

					if($conn -> connect_error)
					{
						die("Connection Failed:".$conn->connect_error);
					}
	
					else
					{
						"Connected Succesfully";
					}				
					
					
						$newfeedID = $_POST['id'];
						$newName = $_POST['nm'];
						$newComment = $_POST['cm'];
						
						$sql = "UPDATE feedback 
								SET Name = '$newName',
									comment = '$newComment'
								WHERE id = '$newfeedID'";
								
						if(mysqli_query ($conn , $sql))
						{
							echo "<script>alert('Records are updated')</script>";		

						}							
					
						else
						{
							echo "<script>alert('Error')</script>";
						}
					?>

						<table border = "1" width = "100%">
						<tr>
							<th>Feedback ID</th>
							<th>Name</th>
							<th>Comment</th>
							<th>Change</th>
							<th>Delete</th>
						</tr>	
					
		
				<?php	
					$sql = "SELECT * FROM feedback";
							
							if($result = $conn->query($sql))
							{
								if($result->num_rows>0)
								{
									while($row = $result->fetch_assoc())
									{
										$id = $row['id'];
										
										echo "<tr>
												<td>".$row["id"]."</td> 
												<td>".$row["Name"]."</td> 
												<td>".$row["Comment"]."</td>
												<td><button input type = 'submit'><a href = 'feedbackUpdate.php?id=$id'>Edit</a></button></td>
												<td><button input type = 'submit'><a href = 'deleteFeedback.php?id=$id'>Delete</a></button></td>
											  </tr>";
									}		  
						
									
										
								}	
							}
		
							else
							{
								echo "No results!";
							}
							
							echo "</table>";
							
						
					
					?>	
						
					
					
							
				
	
		
			
							
					
		
			<footer class="footer-distributed">
				<br><br><br><br><br><br>
					<p>Eventia ! &copy; 2019</p>
				
				<div>
					<p><span>207,New road Kandy,</span><br><br>Sri lanka</p>
				</div>

				<div>
					<p>+9481123256</p>
				</div>

				<div>
					<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
				</div>

				<p> 
					<span>About Eventia</span>
					Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
				</p>

			</footer>
		
		

	</body>
	
	
	
	</html>




























		
		
		
		
		
		
		
		
		
				
		
		

	
		





























		
		
		
		
		
		
		
		
		
				
		
		












		
		
		
		
		
		
		
		
		
				
		
		



















		
		
		
		
		
		
		
		
		
				
		
		
