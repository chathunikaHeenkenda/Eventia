<?php
	
	require 'config.php';
	
	$id = $_POST["id"];			
	$eventNew=$_POST["event"];
	$dateNew=$_POST["date1"];
	$timeNew=$_POST["time"];
	$hotelNew=$_POST["hotel"];
	$decoNew=$_POST["deco"];
	$carNew=$_POST["car"];
	$newnumber=$_POST["no_of_visit"];
	$newtheme=$_POST["theme"];
	$newphone=$_POST["phone"];
	
	
	$sql="UPDATE reservation SET Event_type='$eventNew',
									Date='$dateNew',
									Time='$timeNew',
									Theme='$newtheme',
									Phone='$newphone',
									Hotel='$hotelNew',
									Decoration='$decoNew',
									Car='$carNew',
									No_of_visitors='$newnumber'
									where EventNo='$id'";
									
									
									
	if(mysqli_query($conn,$sql))
	{
		echo "<script> alert('Records updated succesfully')</script>";
		header('Location:index.php');
		
		
	}
	else{
		
		echo "<script>alert('error')</script>".$conn->error;
	}
									
									
	mysqli_close($conn)	;							
									
	
?>