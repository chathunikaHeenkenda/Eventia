<?php

require 'config.php';

$id =$_POST["id"];
$Deco_name_new =$_POST["dname"];
$price_new =$_POST["dprice"];


$sql = "update car SET
						Decoration = '$Deco_name_new',
						price= '$price_new'
					where ID = '$id'";
						
						if (mysqli_query($conn, $sql))
						{
							
							echo "<script>alert('Record updated successfully!!')</script>";
							header("location:viewdeco.php");
							
							
							
						}
						else {
							
							echo"<script> alert ('error in updating the record')</script>";
							
							
						}
							mysqli_close($conn);


?>