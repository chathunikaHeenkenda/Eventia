<?php

require 'config.php';

$id =$_POST["id"];
$Hotel_name_new =$_POST["hname"];
$price_new =$_POST["hprice"];


$sql = "update hotel SET

						HotelName = '$Hotel_name_new',
						price= '$price_new'
					where ID = '$id'";
						
						if (mysqli_query($conn, $sql))
						{
							
							echo "<script >alert ('Record updated successfully!!') </script>";
							header("location:viewhotels.php");
							
							
							
						}
						else {
							
							echo"<script> alert ('error in updating the record')</script>";
							
							
						}
							mysqli_close($conn);


?>