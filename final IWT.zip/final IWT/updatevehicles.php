<?php

require 'config.php';

$id =$_POST["id"];
$Vehicle_name_new =$_POST["vname"];
$price_new =$_POST["vprice"];


$sql = "update car SET
						Car = '$Vehicle_name_new',
						price= '$price_new'
					where ID = '$id'";
						
						if (mysqli_query($conn, $sql))
						{
							
							echo "<script>alert('Record updated successfully!!')</script>";
							header("location:viewvehicle.php");
							
							
							
						}
						else {
							
							echo"<script> alert ('error in updating the record')</script>";
							
							
						}
							mysqli_close($conn);


?>