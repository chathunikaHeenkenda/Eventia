<?php
	require 'config.php';
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel  = "stylesheet" href="style/annistyle.css">
		<!--add a title-->
		<title>EVENTIA</title>
		
	</head>
	
	<body>
		<!--add a logo-->
		<img id="logo" src = "images/logo2.jpg">
		
		<div style="left:95%;position:absolute;top:17%;font-size:20px;">
		<?php
		echo $_SESSION['UserName']?></div><a href="profile.php"><img id= "avatar" src = "images/avatar.png"></a>
		
		<!--add a header-->
		<h1 id="eventia">eVENTiA</h1>
		<!--navigation bar-->
		<ul id="topnav">
			<li><a href="home.php">Home</a></li>
			<li><a href="aboutus.php">About us</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="reserv.php">Reservation</a></li>
			<li><a href="logout.php">Log Out</a></li>
			<li><a href="view.php">View</a></li>
		</ul>
		
		
			<h3>Your Reservation is as follow.....</h3>
			<br><br>
			<div>
				<table border ="1" style="font-size:20px; width = '100%';">
					<tr>
						<th>Event No</th>
						<th>Event Type</th>
						<th>Date</th>
						<th>Time</th>
						<th>Theme</th>
						<th>User_id</th>
						<th>Hotel</th>
						<th>Decoration</th>
						<th>Car</th>
						<th>Number of visitors</th>
						<th>Delete</th>
						
					</tr>			
			</div>
			
			
			
			<!--get data from database-->
			<?php
			
				
				$x = $_SESSION['user_id'];
				$sql = "SELECT * FROM reservation where phone = '$x'";
				$result= $conn->query($sql);
				
				if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc())
					{
						$id = $row['EventNo'];
						echo "<tr> <td>".$row['EventNo']."</td>
							<td>".$row['Event_type']."</td>
							<td>".$row['Date']."</td>
							<td>".$row['Time']."</td>
							<td>".$row['Theme']."</td>
							<td>".$row['Phone']."</td>
							<td>".$row['Hotel']."</td>
							<td>".$row['Decoration']."</td>
							<td>".$row['Car']."</td>
							<td>".$row['No_of_visitors']."</td>
							<td><button type='submit'><a href='deletereser.php?id=$id'>Delete</a></button></td>

						</tr>";
					}
				}
				else{
					echo "0 results";
				}
				
				echo "</table>";
			
			?>
			
		</div>
		<center>
			
			
	
			

				
				

				
			</div>
		

	</body>
	
	<footer class="footer-distributed">
						<br><br><br>
						<p>Eventia ! &copy; 2019</p>
						
						<p>207,New road Kandy,<br><br>Sri lanka</p>

						<p>+9481123256</p>

						<p><a href="mailto:support@company.com">Eventia@event.com</a></p>
						
						<p> 
						About Eventia:
						Eventia is an online event planning web application.Eventia comes in handy since we provide all the services for all events only a fingertip away.
						</p>

	</footer>

</html>