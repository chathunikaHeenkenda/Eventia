	<html>
<head>
<link rel  = "stylesheet" href="admin.css">
</head>
<body>	
<div id = "header" style="height:150px;">
		<?php
		date("y-m-d");
		?>
		
		<img src = "images/images/logo2.jpg" width="100px" height="100px">
		
		<center><img src = "avatar.png" alt = "admin logo" id = "adminlogo" style="top:5%;position:absolute;"></center>
		</div>
		
		<div id = "sidebar">
		</div>
		
		<div id = "data"><br>
		<center>
			<div>
				<table border="1" width="75%">
				
				<tr>
					<th>Hotel name</th>
					<th>Price</th>
					<th>Edit</th>
					<th>Delete</th>
					
				</tr>
		
		<?php
				require 'config.php';
				
				$sql="SELECT * FROM hotel";
				
				$result=$conn->query($sql);
				
				if($result -> num_rows >0)
				{
					while($row =$result->fetch_assoc())
					{
						$id=$row['ID'];
						
						echo "<tr>
								<td>" .$row["HotelName"]."</td>
								<td>" .$row["Price"]."</td>
								
								<td> <button type='submit'> <a href='edithotels.php?ID=$id'>Edit</a></button></td>	
								<td> <button type='submit' value='Delete'> <a href = 'deletehotels.php?id=$id'>Delete</a></button></td>	
								</tr>";
								
					}
				}
				else
				{
					echo "no results";
					
				}
				echo "</table>";
				
				?>	
			</div>	
		</center>
		</div>
	</body>
</html>	